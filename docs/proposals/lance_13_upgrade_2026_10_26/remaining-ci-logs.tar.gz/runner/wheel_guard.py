import sys
from pathlib import Path
from importlib.metadata import version
import tomllib

def pytest_sessionstart(session):
    import uni_db
    want = tomllib.loads(Path('/home/rohit/work/dragonscale/uni/Cargo.toml').read_text())['workspace']['package']['version']
    assert 'site-packages' in uni_db.__file__, uni_db.__file__
    assert version('uni-db') == want, (version('uni-db'), want)
    print('Wheel guard:', sys.version, uni_db.__file__, want)
