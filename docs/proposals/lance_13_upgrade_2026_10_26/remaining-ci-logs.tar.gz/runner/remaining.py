import json
import os
from pathlib import Path
import subprocess
import sys
import time

repo = Path('/home/rohit/work/dragonscale/uni')
root = Path('/tmp/uni-lance-upgrade/remaining')
root.mkdir(exist_ok=True)
env = dict(os.environ, RUSTC_WRAPPER='', CARGO_BUILD_JOBS='6', RUST_BACKTRACE='1')
exclude = sum((['--exclude', p] for p in ['uni-python', 'uni-tck', 'uni-python-onnx', 'uni-python-cuda', 'uni-python-metal', 'uni-python-onnx-cuda', 'uni-python-onnx-metal']), [])
groups = {
 'quick': [
  ('publish-list', ['python3', 'scripts/ci/check_publish_list.py'], {}, repo),
  ('cuda-metadata', ['cargo', 'metadata', '--format-version=1', '--manifest-path', 'bindings/uni-db-cuda/Cargo.toml'], {}, repo),
  ('iai-gate-selftest', ['python3', 'scripts/perf/test_iai_gate.py'], {}, repo),
  ('iai-collector-selftest', ['python3', 'scripts/perf/test_iai_collect.py'], {}, repo),
  ('generated-locy', ['python3', 'website/scripts/generate_locy_notebooks.py', '--check'], {}, repo),
  ('generated-semiconductor', ['python3', 'website/scripts/generate_semiconductor_flagship_notebook.py', '--check'], {}, repo),
  ('generated-pharma', ['python3', 'website/scripts/generate_pharma_flagship_notebook.py', '--check'], {}, repo),
  ('generated-cyber', ['python3', 'website/scripts/generate_cyber_flagship_notebook.py', '--check'], {}, repo),
  ('pydantic-mypy314', [str(repo/'bindings/uni-pydantic/.venv/bin/python'), '-m', 'mypy', '--python-version', '3.14', 'src'], {}, repo/'bindings/uni-pydantic'),
 ],
 'miri': [
  ('miri-setup', ['cargo', '+nightly-2026-07-11', 'miri', 'setup'], {}, repo),
  ('miri-btic', ['cargo', '+nightly-2026-07-11', 'miri', 'test', '-p', 'uni-btic', '--lib', '--tests'], {}, repo),
  ('miri-sparse', ['cargo', '+nightly-2026-07-11', 'miri', 'test', '-p', 'uni-sparse-vector', '--lib', '--tests'], {}, repo),
  ('miri-common', ['cargo', '+nightly-2026-07-11', 'miri', 'test', '-p', 'uni-common', '--lib', '--tests', '--', '--test-threads=1', '--skip', 'muvera::'], {'MIRIFLAGS':'-Zmiri-disable-isolation'}, repo),
  ('miri-crdt', ['cargo', '+nightly-2026-07-11', 'miri', 'test', '-p', 'uni-crdt', '--lib', '--', '--test-threads=1'], {}, repo),
 ],
 'rust': [
  ('wasm-fixtures', ['bash', 'scripts/build-wasm-fixtures.sh'], {}, repo),
  ('recovery-default', ['cargo','nextest','run','-p','uni-store','-E','test(/resilience|recovery/)'], {}, repo),
  ('loom-pr', ['cargo','nextest','run','-p','uni-store','--features','loom','--test','occ_model'], {'LOOM_MAX_PREEMPTIONS':'2'}, repo),
  ('gc-trace', ['cargo','nextest','run','-p','uni-plugin-builtin','-p','uni-plugin-rhai','-E','test(graph_compute)'], {'UNI_GC_TRACE':'1'}, repo),
  ('metamorphic-smoke', ['cargo','nextest','run','-p','uni-db','--test','integration','-E','test(/metamorphic::/) and not test(soak)'], {'METAMORPHIC_CASES':'64'}, repo),
  ('onnx-wheel-isolated', ['cargo','check','-p','uni-python-onnx'], {}, repo),
  ('reranker-bundled', ['cargo','nextest','run','-p','uni-db','--features','provider-onnx','--test','reranker_integration','--run-ignored','all','-E','not test(=test_real_onnx_cross_encoder_reranks_by_relevance)'], {}, repo),
  ('reranker-dynamic', ['cargo','nextest','run','-p','uni-db','--no-default-features','--features','provider-onnx-dynamic','--test','reranker_integration'], {'ORT_DYLIB_PATH':'/tmp/uni-ci-local-20261025/onnxruntime-linux-x64-1.20.1/lib/libonnxruntime.so'}, repo),
  ('rustdoc', ['cargo','doc','--no-deps','--workspace',*exclude], {'RUSTDOCFLAGS':'-D warnings'}, repo),
 ],
 'site': [
  ('site-convert', ['uv','run','--no-project','--with','nbconvert','python','scripts/convert_notebooks.py','--no-execute'], {}, repo/'website'),
  ('site-build', ['uv','run','--no-project','--with','zensical','--with','pymdown-extensions','zensical','build','--strict'], {}, repo/'website'),
 ],
}
db312=repo/'target/ci-remaining/db312'
wheel_env={'VIRTUAL_ENV':str(db312),'PATH':str(db312/'bin')+':'+env['PATH'],'PYTHONSAFEPATH':'1','PYTHONPATH':str(root)}
groups['wheel'] = [
 ('wheel-build312',[str(db312/'bin/maturin'),'build','--interpreter',str(db312/'bin/python'),'--out',str(repo/'target/ci-remaining/wheel')],wheel_env,repo/'bindings/uni-db'),
 ('wheel-install',['python3',str(root/'install-wheel.py')],{},repo),
 ('wheel-db312-tests',[str(db312/'bin/pytest'),'tests/','-v','-n','auto','-p','wheel_guard'],wheel_env,repo/'bindings/uni-db'),
 ('wheel-db312-stubs',[str(db312/'bin/python'),'-m','mypy.stubtest','uni_db','--mypy-config-file','stubtest-mypy.ini','--allowlist','stubtest-allowlist.txt','--ignore-unused-allowlist','--ignore-positional-only','--ignore-disjoint-bases'],wheel_env,repo/'bindings/uni-db'),
 *[(f'wheel-ogm{minor}-tests',[str(repo/f'target/ci-remaining/ogm{minor}/bin/pytest'),'tests/','-v','-n','auto','-p','wheel_guard'],{'PYTHONPATH':str(root),'PYTHONSAFEPATH':'1'},repo/'bindings/uni-pydantic') for minor in ['312','314']],
 ('wheel-ogm314-mypy',[str(repo/'target/ci-remaining/ogm314/bin/mypy'),'--python-version','3.14','src'],{'PYTHONSAFEPATH':'1'},repo/'bindings/uni-pydantic'),
 *[(f'notebook-{name}',[str(db312/'bin/python'),f'website/scripts/verify_{name}_flagship_notebook.py'],{'PYTHONPATH':'','PYTHONSAFEPATH':'1'},repo) for name in ['semiconductor','pharma','cyber','predictive_maintenance','adverse_drug_reaction','drug_drug_interaction']],
]
groups['python-wasm'] = [
 ('wasm-python-build',[str(db312/'bin/maturin'),'develop','--features','wasm-plugins,extism-plugins'],wheel_env,repo/'bindings/uni-db'),
 ('wasm-python-guard',[str(db312/'bin/python'),'-c',"import uni_db._uni_db as e; assert all(hasattr(e.Uni,m) for m in ('load_wasm_component','load_wasm_extism')); print('Both WASM loaders present')"],wheel_env,repo),
 ('wasm-python-tests',[str(db312/'bin/pytest'),'tests/test_wasm_plugin.py','tests/test_plugin_conformance.py','tests/test_stub_drift.py','-v'],wheel_env,repo/'bindings/uni-db'),
 ('wasm-python-stubs',[str(db312/'bin/python'),'-m','mypy.stubtest','uni_db','--mypy-config-file','stubtest-mypy.ini','--allowlist','stubtest-allowlist.txt','--ignore-unused-allowlist','--ignore-positional-only','--ignore-disjoint-bases'],wheel_env,repo/'bindings/uni-db'),
]
groups['nightly-model'] = [
 ('loom-nightly',['cargo','nextest','run','-p','uni-store','--features','loom','--test','occ_model'],{'LOOM_MAX_PREEMPTIONS':'3'},repo),
 ('shuttle',['cargo','nextest','run','-p','uni-store','--features','shuttle','--test','occ_model'],{},repo),
]
groups['nightly-soak'] = [
 ('soak-stress',['cargo','nextest','run','--profile','soak','-p','uni-db','-p','uni-store','-p','uni-locy-oracle','--run-ignored','ignored-only','-E','(test(/soak/) | test(/stress/)) and not test(/dqp::/)'],{'UNI_FORK_SOAK_FORKS':'40','UNI_FORK_SOAK_MUTATIONS':'300','UNI_FORK_SOAK_RESTARTS':'4','ORACLE_SOAK_CASES':'10000'},repo),
 ('metamorphic-soak',['cargo','nextest','run','--profile','soak','-p','uni-db','--test','integration','--run-ignored','ignored-only','-E','test(/metamorphic::/) and test(soak) and not test(/dqp::/)'],{'METAMORPHIC_CASES':'50000'},repo),
 ('dqp-soak',['cargo','nextest','run','--profile','soak','-p','uni-db','--test','integration','--run-ignored','ignored-only','-E','test(/metamorphic::dqp::/) and test(soak)'],{'DQP_CASES':'10000'},repo),
]
groups['sweep'] = [
 ('ignored-sweep',['bash','-c','cargo nextest run --profile soak --workspace --no-fail-fast --exclude uni-tck --exclude uni-python --exclude uni-python-onnx --exclude uni-python-cuda --exclude uni-python-metal --exclude uni-python-onnx-cuda --exclude uni-python-onnx-metal --run-ignored ignored-only -E "$(python3 scripts/ci/ignored_tests.py sweep-filter)"'],{},repo),
]
groups['tsan'] = [
 ('tsan',['cargo','+nightly','nextest','run','-Z','build-std','--target','x86_64-unknown-linux-gnu','-p','uni-db','--test','integration','--test-threads','1','-E','test(/ssi_invariants::/) | test(/ssi_occ_e2e::/) | test(/ssi_stress::/)'],{'RUSTFLAGS':'-Zsanitizer=thread','PROPTEST_CASES':'16','TSAN_OPTIONS':f'suppressions={repo}/.config/tsan-suppressions.txt:halt_on_error=0:exitcode=66:second_deadlock_stack=1:history_size=4','CARGO_TARGET_DIR':str(repo/'target/ci-remaining/tsan')},repo),
]
groups['fuzz-smoke'] = [('fuzz-lock',['cargo','+nightly','metadata','--locked','--format-version','1'],{},repo/'fuzz')]
groups['fuzz-nightly'] = []
for target in ['cypher_parse','locy_parse','wal_decode','btic_decode']:
 (repo/'fuzz/corpus'/target).mkdir(parents=True,exist_ok=True)
 seeds=['seeds/'+target] if (repo/'fuzz/seeds'/target).exists() else []
 groups['fuzz-smoke'].append(('fuzz-smoke-'+target,['cargo','+nightly','fuzz','run','--target','x86_64-unknown-linux-gnu',target,'corpus/'+target,*seeds,'--','-max_total_time=30','-timeout=10'],{},repo/'fuzz'))
 groups['fuzz-nightly'].append(('fuzz-nightly-'+target,['cargo','+nightly','fuzz','run','--target','x86_64-unknown-linux-gnu',target,'--','-max_total_time=300','-timeout=10'],{},repo/'fuzz'))
groups['perf'] = [
 ('bench-build',['cargo','bench','-p','uni-db','--bench','hot_paths_iai','--no-run'],{},repo),
 ('iai-measure',['bash','scripts/perf/iai_pilot.sh','5'],{},repo),
 ('iai-compare',['python3','scripts/perf/iai_gate.py','--baseline','docs/perf/iai-baseline.json','--current','target/iai-pilot','--fail-pct','2','--warn-pct','1','--fail-improve-pct','50','--markdown'],{},repo),
]
groups['bench-nightly'] = [
 ('bench-registration',['python3','-c','import pathlib,tomllib; p=pathlib.Path("crates/uni"); cfg=tomllib.loads((p/"Cargo.toml").read_text()); missing={x.stem for x in (p/"benches").glob("*.rs")}-{x["name"] for x in cfg.get("bench",[])}; print("Missing bench stanzas:",sorted(missing)); assert not missing'],{},repo),
 ('bench-check',['cargo','check','-p','uni-db','--benches'],{},repo),
 *[(name,['cargo','bench','-p','uni-db','--bench',name],{},repo) for name in ['ssi_commit_overhead','concurrent_mutations','commit_throughput']],
]
rows = json.loads((root/'results.json').read_text()) if (root/'results.json').exists() else []
group = sys.argv[1]
selected = set(sys.argv[2:])
for name, command, extra, cwd in groups[group]:
 if selected and name not in selected: continue
 print('START', name, flush=True)
 start = time.time()
 (root/'active.json.tmp').write_text(json.dumps({'lane':name,'command':command,'started':start,'state':'running'})+'\n')
 (root/'active.json.tmp').replace(root/'active.json')
 with (root/(name+'.log')).open('w') as log:
  code = subprocess.call(command,cwd=cwd,env=env|extra,stdout=log,stderr=subprocess.STDOUT)
 row={'lane':name,'command':command,'environment':extra,'cwd':str(cwd),'exit_code':code,'seconds':round(time.time()-start,3)}
 rows = json.loads((root/'results.json').read_text()) if (root/'results.json').exists() else []
 rows.append(row)
 (root/'results.json').write_text(json.dumps(rows,indent=2)+'\n')
 print('END',name,code,flush=True)
 (root/'active.json.tmp').write_text(json.dumps({'lane':name,'exit_code':code,'state':'finished'})+'\n')
 (root/'active.json.tmp').replace(root/'active.json')
 if code: sys.exit(code)
