from pathlib import Path
import subprocess
import sys
import json
import hashlib
import mmap

repo = Path('/home/rohit/work/dragonscale/uni')
wheel, = (repo/'target/ci-remaining/wheel').glob('*.whl')
records = []
for label in ['db312','ogm312','ogm314']:
    python = repo/'target/ci-remaining'/label/'bin/python'
    subprocess.run(['uv','pip','install','--python',str(python),'--force-reinstall',str(wheel)],check=True)
    subprocess.run([str(python),'-c',"import sys,uni_db; from importlib.metadata import version; assert 'site-packages' in uni_db.__file__,uni_db.__file__; assert version('uni-db')=='4.2.0'; print(sys.version,uni_db.__file__,version('uni-db'))"],cwd=repo,check=True)
    native = next((repo/'target/ci-remaining'/label).glob('lib/python*/site-packages/uni_db/_uni_db*.so'))
    with native.open('rb') as f, mmap.mmap(f.fileno(),0,access=mmap.ACCESS_READ) as mm:
        assert mm.find(b'/lance-13.0.0/') >= 0
        assert mm.find(b'/lance-11.0.0/') < 0
        records.append({'environment':label,'native':str(native),'sha256':hashlib.sha256(mm).hexdigest(),'lance_13_source_paths':True})
assert len({row['sha256'] for row in records}) == 1, records
Path('/tmp/uni-lance-upgrade/remaining/installed-wheel-binaries.json').write_text(json.dumps(records,indent=2)+'\n')
