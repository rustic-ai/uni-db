import json
import os
from pathlib import Path
import subprocess
import sys
import time

repo = Path('/home/rohit/work/dragonscale/uni')
root = Path('/tmp/uni-lance-upgrade/remaining')
env = dict(os.environ, RUSTC_WRAPPER='', CARGO_BUILD_JOBS='6', RUST_BACKTRACE='1')
def phase(name):
    (root/'phase.json').write_text(json.dumps({'phase':name,'time':time.time()})+'\n')
    print('PHASE',name,flush=True)
phase('waiting-for-miri-crdt')
while True:
    rows = json.loads((root/'results.json').read_text())
    done = [row for row in rows if row['lane']=='miri-crdt']
    if done:
        if done[-1]['exit_code']: sys.exit(done[-1]['exit_code'])
        break
    time.sleep(2)
rows.extend(row for row in json.loads((root/'site-results.json').read_text()) if row['lane'] not in {item['lane'] for item in rows})
(root/'results.json').write_text(json.dumps(rows,indent=2)+'\n')

def restore_default():
    source = repo/'target/ci-remaining/default-binding/_uni_db.abi3.so'
    target = repo/'bindings/uni-db/uni_db/_uni_db.abi3.so'
    temporary = target.with_name(target.name+'.ci-restore')
    subprocess.run(['cp','--reflink=always',str(source),str(temporary)],check=True)
    os.replace(temporary,target)
    print('RESTORED default Lance 13 native extension',flush=True)

def restore_examples_compression():
    saved=root/'examples-compression.json'
    if not saved.exists(): return
    state=json.loads(saved.read_text())
    value=state['before'].partition('=')[2] if state['before'] else ''
    subprocess.run(['btrfs','property','set',state['directory'],'compression',value],check=True)
    state['restored']=True
    saved.write_text(json.dumps(state,indent=2)+'\n')
    print('RESTORED example build-directory compression preference',flush=True)

for group in (sys.argv[1:] or ['rust','wheel','python-wasm','nightly-model','fuzz-smoke','fuzz-nightly','perf','bench-nightly','tsan','nightly-soak','sweep']):
    phase(group)
    try:
        code = subprocess.call([sys.executable,'/tmp/uni-lance-upgrade/remaining.py',group],cwd=repo,env=env)
    finally:
        if group=='python-wasm': restore_default()
        if group=='sweep': restore_examples_compression()
    if code:
        phase('needs-triage-'+group)
        sys.exit(code)
phase('complete')
